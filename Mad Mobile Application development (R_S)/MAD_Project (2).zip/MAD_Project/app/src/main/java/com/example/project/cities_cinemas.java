package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class cities_cinemas extends AppCompatActivity implements AdapterView.OnItemSelectedListener
{
    Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cities_cinemas);
        spinner=findViewById(R.id.city_name);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.cinemas_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
    {
        String item = parent.getItemAtPosition(position).toString();
        ListView mylistview = findViewById(R.id.myList);
        if (item.equals("Lahore"))
        {
            String[] Lahorecinemas = {"Universal Cinema", "Cinepax", "Cine Star", "Imax", "Super Cinema"};
            Integer [] imgid={R.drawable.universalcinema,R.drawable.cinepax,R.drawable.cinestar,R.drawable.imax,R.drawable.supercinema};
            ArrayAdapter myarrayAdapter = new customAdapter(this, Lahorecinemas,imgid);
            mylistview.setAdapter(myarrayAdapter);

        }
        else if(item.equals("Islamabad"))
        {
            String[] Islamabadcinemas = {"CineGold Plex", "Cine Star", "Arena", "The Centaurus Cineplax", "JFC Cineplex"};
            Integer [] imgid={R.drawable.kcinegold,R.drawable.cinestar,R.drawable.arenaislbd,R.drawable.cineplax,R.drawable.jfccinemaislbd};
            ArrayAdapter myarrayAdapter = new customAdapter(this, Islamabadcinemas,imgid);
            mylistview.setAdapter(myarrayAdapter);
        }
        else if(item.equals("Karachi"))
        {
            String[] Karachicinemas = {"Atrium Cinema", "Capri Cinema", "Cine Gold", "Cine plax", "Nuplex Cinema"};
            Integer [] imgid={R.drawable.katriumcinemas,R.drawable.kcapricinema,R.drawable.kcinegold,R.drawable.cineplax,R.drawable.knuplexcinema};
            ArrayAdapter myarrayAdapter = new customAdapter(this, Karachicinemas,imgid);
            mylistview.setAdapter(myarrayAdapter);

        }
        else if(item.equals("Faisalabad"))
        {
            String[] Faisalabadcinemas = {"Nagina Cinema", "Cineplax", "Regal Cinema", "Imax", "Taj Mahal"};
            Integer [] imgid={R.drawable.fnaginacinema,R.drawable.cineplax,R.drawable.fregalcinema,R.drawable.imax,R.drawable.ftajmahal};
            ArrayAdapter myarrayAdapter = new customAdapter(this, Faisalabadcinemas,imgid);
            mylistview.setAdapter(myarrayAdapter);

        }
        else if(item.equals("Rawalpindi"))
        {
            String[] Rawalpindicinemas = {"CineGold Plex", "Cine Star", "Arena", "The Centaurus Cineplax"};
            Integer [] imgid={R.drawable.kcinegold,R.drawable.cinestar,R.drawable.arenaislbd,R.drawable.cineplax};
            ArrayAdapter myarrayAdapter = new customAdapter(this, Rawalpindicinemas,imgid);
            mylistview.setAdapter(myarrayAdapter);
        }
        else if(item.equals("Gujranwala"))
        {
            String[] Gujaranwalacinemas = {"Cinepax", "Zinco Cinema", "Opera Cinema"};
            Integer [] imgid={R.drawable.cinepax,R.drawable.zincocinemagujranwala,R.drawable.theoperacinemahallguj};
            ArrayAdapter myarrayAdapter = new customAdapter(this, Gujaranwalacinemas,imgid);
            mylistview.setAdapter(myarrayAdapter);
        }
        else
        {
        }


        mylistview.setOnItemClickListener(
                new AdapterView.OnItemClickListener()
                {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id)
                    {

                        gotomoviesgrid();
                    }
                }
        );
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    public void gotomoviesgrid()
    {
        Intent i=new Intent(this,moviesgrid.class);
        startActivity(i);
    }
}
