package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.net.PasswordAuthentication;
import java.util.Date;

import static java.lang.Integer.parseInt;

public class sign_up extends AppCompatActivity {
    EditText lastname;
    EditText firstname;
    EditText Userid;
    EditText Password;
    EditText phonenumber;
    EditText Dateofbirth;
    RadioGroup Gender;
    RadioButton genderentered;
    int c;
    SQLiteHelper mt_database;
    Button btnadd;
    boolean a=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        mt_database=new SQLiteHelper(this);

        firstname=findViewById(R.id.fnam_enter);
        lastname=findViewById(R.id.lname_enter);
        Userid=findViewById(R.id.user_id);
        phonenumber=findViewById(R.id.phonenumber_enter);
        Password=findViewById(R.id.password_enter);
        Dateofbirth=findViewById(R.id.dob_enter);
        Gender=findViewById(R.id.gender_enter);
        int radioid=Gender.getCheckedRadioButtonId();
        genderentered=findViewById(radioid);
        btnadd=findViewById(R.id.save_data);
        saveinfo();
    }
    public void saveinfo()
    {
        btnadd.setOnClickListener(
                new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        boolean isInserted = mt_database.insertData(
                                Userid.getText().toString(),
                                phonenumber.getText().toString(),
                                firstname.getText().toString(),
                                lastname.getText().toString(),
                                Password.getText().toString(),
                                Dateofbirth.getText().toString()
                        );
                        if(isInserted == true)
                        {
                            Toast.makeText(sign_up.this, "Sign Up Completed", Toast.LENGTH_SHORT).show();
                            gotologin();
                        }
                        else
                        {
                            Toast.makeText(sign_up.this, "Sorry Coud not Sign Up. Try Again", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );


    }
    public void gotologin()
    {
     Intent i=new Intent(this,MainActivity.class);
     startActivity(i);

    }
}
