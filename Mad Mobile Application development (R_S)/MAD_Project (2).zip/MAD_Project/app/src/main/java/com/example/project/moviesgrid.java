package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

public class moviesgrid extends AppCompatActivity
{

    GridView moviegrid;
//String[] values= {"End Game","Bahubali","Sahoo","Doilet","Bad Boyes","Dubang3","Sonic","Soriyavanshi","Darbar","Bharat","Frozan 2"};
         String[] values={"James bond","Dolittle","Sonic","Soriyavanshi","Dabang3","Darbar","Bahubali","Sahoo",
        "Bharat","Bad Boys"," Avengers","Baaghi3","Ëternals","Happy Hardy Heer","Panga","Tanhaji","Black Widow","India's Most Wanted","Romeo Akbar Walter","Total Dhamaal","21 Bridghes","Alladin","Star Wars","The Intruder"};

    String[] upcoming_movies={"Baghi3","SuriyaWnshi","Black Widow","Eternals","Turning","Malang","Hacked","Total Recall","Guardian Of The Galaxy Vol2","Prodigy","Will Gardener"};
    int [] upcoming_img=
            {
                    R.drawable.baaghi3,
                    R.drawable.c4,
                    R.drawable.blackwidow,
                    R.drawable.eternals,
                    R.drawable.turningupcoming,
                    R.drawable.malangupcoming,
                    R.drawable.hackedupcoming,
                    R.drawable.totalrecall,
                    R.drawable.guardianupcoming,
                    R.drawable.prodigyupcoming,
                    R.drawable.willgardenerupcoming
            };


    int [] i_m_g={
        R.drawable.c1,
        R.drawable.c2,
        R.drawable.c3,
        R.drawable.c4,
        R.drawable.d,
        R.drawable.dr,
        R.drawable.m7,
        R.drawable.m8,
        R.drawable.m14,
        R.drawable.bharat,
        R.drawable.e,
        R.drawable.baaghi3,
        R.drawable.eternals,
        R.drawable.happyhardyheer,
        R.drawable.panga,
        R.drawable.tanhaji,
        R.drawable.blackwidow,
            R.drawable.indiamostwanted,
            R.drawable.raw,
            R.drawable.totaldhamaal,
            R.drawable.bridges,
            R.drawable.alladin,
            R.drawable.starwars,
            R.drawable.theintruder
};
    String [] now_showing={"James bond","Dolittle","Sonic","Soriyavanshi","Dabang3","Darbar","Bahubali","Sahoo",
        "Bharat","Bad Boys"," Avengers","Baaghi3","Ëternals","Happy Hardy Heer","Panga","Tanhaji"};
    int []now_show_img=
            {
                    R.drawable.c1,
                    R.drawable.c2,
                    R.drawable.c3,
                    R.drawable.c4,
                    R.drawable.d,
                    R.drawable.dr,
                    R.drawable.m7,
                    R.drawable.m8,
                    R.drawable.m14,
                    R.drawable.bharat,
                    R.drawable.e,
                    R.drawable.baaghi3,
                    R.drawable.eternals,
                    R.drawable.happyhardyheer,
                    R.drawable.panga,
                    R.drawable.tanhaji
            };
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moviesgrid);
        moviegrid=findViewById(R.id.my_grid);
        grid_Adapter grid_adapter=new grid_Adapter(values,i_m_g,this);
        moviegrid.setAdapter(grid_adapter);
    }


    public void now_change_a(View v)
    {
        grid_Adapter grid_adapter=new grid_Adapter(now_showing,now_show_img,this);

        moviegrid.setAdapter(grid_adapter);
    }
    public void upcoming_change_a(View v)
    {
        grid_Adapter grid_adapter=new grid_Adapter(upcoming_movies,upcoming_img,this);

        moviegrid.setAdapter(grid_adapter);
    }
}
