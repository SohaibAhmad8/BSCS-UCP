package com.example.project;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class customAdapter extends ArrayAdapter <String>
{

    private String[] cineman;
    private Integer[] imageid;
    public customAdapter(@NonNull Context context, String [] cinemaList, Integer [] imgid) {
        super(context, R.layout.custom_row,cinemaList);
        cineman=cinemaList;
        imageid=imgid;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent)
    {
        LayoutInflater myInflater=LayoutInflater.from(getContext());
        View customview=myInflater.inflate(R.layout.custom_row,parent,false);


        TextView cinemanam=customview.findViewById(R.id.tv_cinemaname);
        ImageView cinemaimmage=customview.findViewById(R.id.imageView10);

        cinemanam.setText(cineman[position]);
        cinemaimmage.setImageResource(imageid[position]);
        return customview;
    }
}
