package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class movie_info extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_info);

        ListView mylistview = findViewById(R.id.lista);
        int []a={1,2,3,4,5,6};
            String[] stime = {"11:30","12:00","1:15","5:30","6:00","7:30"};
            String [] slang={"English","English","Urdu","English","Urdu","Urdu"};

            ArrayAdapter myarrayAdapter = new custom_Adapter(this,a,stime,slang);
            mylistview.setAdapter(myarrayAdapter);

    }
}
