package com.example.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.w3c.dom.Text;

public class custom_Adapter extends ArrayAdapter <String> {

    private int []aa;
    private String[] bb;
    private String[] cc;
    public custom_Adapter(@NonNull Context context, int [] a, String []b, String []c)
    {
        super(context, R.layout.show_info,b);
        aa=a;
        bb=b;
        cc=c;
    }

    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater myInflater=LayoutInflater.from(getContext());
        View customview=myInflater.inflate(R.layout.custom_row,parent,false);
        TextView number=customview.findViewById(R.id.tv_show_number);
        TextView showtime=customview.findViewById(R.id.tv_show_time);
        TextView showlanguage=customview.findViewById(R.id.tv_show_lang);
        number.setText(aa[position]);
        showtime.setText(bb[position]);
        showlanguage.setText(cc[position]);
        return customview;
    }
}
