package com.example.project;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.net.ContentHandler;

public class MainActivity extends AppCompatActivity
{
    EditText Uid;
    EditText userpassword;
    boolean p=false,name=false;
    int check,c=-1;
    int i;
    String id;
    SQLiteHelper myDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDatabase = new SQLiteHelper(this);
        Uid=findViewById(R.id.usernameenter);
        userpassword=findViewById(R.id.userpasswordenter);
    }


    public void check_userinfo(View view)
    {
        Cursor res = myDatabase.getAllData();

        if(res.getCount() == 0)
        {
            showMessage("Error", "Nothing Found");
            return;
        }

        StringBuffer buffer = new StringBuffer();
        while(res.moveToNext())
        {
            if(Uid.getText().toString().equals(res.getString(0)))
            {
                name=true;

               // int a=res.getPosition();   it tells the current row index
               // buffer.append("Row Number : " + a + "\n");
                // buffer.append("Matched Id : " + res.getString(0) + "\n");
                // buffer.append("Password in DB : " + res.getString(4) + "\n");
                if(userpassword.getText().toString().equals(res.getString(4)))
                {
                    p=true;
                    gotocities();
                }
                else
                {
                    p=false;
                }

                break;
            }
            else
            {
                name=false;
            }

        }
        if(name==false)
        {
            buffer.append("User Id not found. Kindly Sign Up!" + "\n");
            showMessage("Note", buffer.toString());
        }
        else if(name==true && p==false)
        {
            buffer.append("Wrong Password. Try again!" + "\n");
            showMessage("Note", buffer.toString());

        }

    }

    public void showMessage(String title, String Message)
    {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User cancelled the dialog
            }
        });
        AlertDialog dialog = builder.create();

        dialog.show();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.CYAN));
    }

    public void switch_to_signup(View view)
    {
        Intent i=new Intent(this,sign_up.class);
        startActivity(i);
    }
    public void gotochangepassword(View view)
    {
        Intent i=new Intent(this,search_name.class);
        startActivity(i);
    }
    public void gotocities()
    {
        Intent i=new Intent(this,cities_cinemas.class);
        startActivity(i);
    }
}
