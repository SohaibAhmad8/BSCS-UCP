package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class search_name extends AppCompatActivity {
EditText userid;
TextView warning;
String id;
SQLiteHelper myDatabase;
boolean name=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_name);

        myDatabase = new SQLiteHelper(this);
        userid=findViewById(R.id.user_id_to_c_p);
        warning=findViewById(R.id.tv_warning);
    }
    public void nexttopassword(View view)
    {

        Cursor res = myDatabase.getAllData();


        while(res.moveToNext())
        {
            if(userid.getText().toString().equals(res.getString(0)))
            {
                name=true;
                //c=res.getPosition();
                // int a=res.getPosition();   it tells the current row index
                // buffer.append("Row Number : " + a + "\n");
                // buffer.append("Matched Id : " + res.getString(0) + "\n");
                // buffer.append("Password in DB : " + res.getString(4) + "\n");

                break;
            }
            else
            {
                name=false;
            }

        }
        if(name==false)
        {

            warning.setText("User Id not found!");
        }
        else
        {
            Intent l=new Intent(this,chengePassword.class);
            l.putExtra("id",userid.getText().toString());
            startActivity(l);
        }

    }
}
