package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class chengePassword extends AppCompatActivity
{
EditText p;
String c;
SQLiteHelper myDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        myDatabase=new SQLiteHelper(this);
        setContentView(R.layout.activity_chenge_password);
        p=findViewById(R.id.new_password);
        Bundle dataFromFirst = getIntent().getExtras();

        if (dataFromFirst == null)
        {
            return;
        }

        c = dataFromFirst.getString("id");

    }


    public void conferm(View view)
    {
        Cursor res = myDatabase.getAllData();

        boolean isUpdate=false;
        while(res.moveToNext())
        {
            if(c.equals(res.getString(0)))
            {

                isUpdate = myDatabase.updateData(
                        c,
                        p.getText().toString()
                );



                //c=res.getPosition();
                // int a=res.getPosition();   it tells the current row index
                // buffer.append("Row Number : " + a + "\n");
                // buffer.append("Matched Id : " + res.getString(0) + "\n");
                // buffer.append("Password in DB : " + res.getString(4) + "\n");

                break;
            }
        }
        if(isUpdate == true)
        {
            Toast.makeText(chengePassword.this, "Password has been changed...", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(chengePassword.this, "Data Not Updated", Toast.LENGTH_SHORT).show();
        }
    }
}
