package com.example.project;


import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

    public class SQLiteHelper extends SQLiteOpenHelper
    {

        // if get errors here it means that we did not implemented functions
        // alt + enter : implements, then alt enter first function

        public static final String databaseName = "MTBDatabase.db";
        public static final String tableName = "UserInfo";
        public static final String Col1 = "UserId";
        public static final String Col2="Phone";
        public static final String Col3 = "FirstName";
        public static final String Col4 = "LastName";
        public static final String Col5 = "Password";
        public static final String Col6="DOB";
        public static final String Col7="Gender";


        public SQLiteHelper(@Nullable Context context) {
            //super(context, name, factory, version);
            super(context, databaseName, null, 1);
            // name : ma database ka name,
            // factory : ma cursor factory (library) use krta ha is ma hum na null pass krna ha, cursor library is used for sql statements. is ma default null pra huwa ha
            // version : database version is 1 and it is linked to onCreate and on onUpgrade.

            SQLiteDatabase db = this.getWritableDatabase(); // database ma editing and write in it.
        }

        @Override
        public void onCreate(SQLiteDatabase db) //version 1 ka liya table create kra ga //
        {
            // creating table
            String SQLString = "create table " + tableName +
                    "("
                    + Col1 + " Text Primary Key,"
                    + Col2 + " Text, "
                    + Col3 + " Text, "
                    + Col4 + " Text, "
                    + Col5 + " Text, "
                    + Col6 + " Text, "
                    + Col7 + " Text" +
                    ")";
            db.execSQL(SQLString);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {
            db.execSQL("drop table if exists " + tableName); // if table exists then drop
            onCreate(db);
        }

        // Data Inserting //

        public boolean insertData (String Userid,String phone, String fname, String lname, String password, String dob)
        {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues ourContent = new ContentValues(); //used to insert or update our data //

            // col1 is our rollnumber and it is used for auto-increment//
            ourContent.put (Col1, Userid); // key is column and value you want to insert //
            ourContent.put (Col2, phone);
            ourContent.put (Col3, fname);
            ourContent.put (Col4, lname);
            ourContent.put (Col5, password);
            ourContent.put (Col6, dob);
          //  ourContent.put (Col7, gender);

            long result = db.insert(tableName, null, ourContent); // 3 parameter is used to what we want to enter , 1 parameter is table name //

            if(result == -1)
            {
                return false;
            }
            else
            {
                return true;
            }
        }


        public Cursor getAllData()
        {
            SQLiteDatabase db = this.getWritableDatabase();
            Cursor result = db.rawQuery("select * from " + tableName, null);

            return result;

            //db.rawQuery("select id, name from people where name = ? and id = ?" new string
        }
        public boolean updateData(String userid, String password)
        {
            SQLiteDatabase db = this.getWritableDatabase();
            Cursor result = db.rawQuery("select * from " + tableName, null);

            ContentValues forUpdate = new ContentValues();
            forUpdate.put(Col5,password);
            long updateResul=db.update(tableName,forUpdate,"UserId = ?",new String[] { userid});
            if(updateResul == -1)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }

