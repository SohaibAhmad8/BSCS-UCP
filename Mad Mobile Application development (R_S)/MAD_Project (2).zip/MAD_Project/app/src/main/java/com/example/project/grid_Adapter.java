package com.example.project;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class grid_Adapter extends BaseAdapter {
    private final String [] movies;
    private final int [] imgs;
    Context context;
    View view;
    LayoutInflater layoutInflater;

    public grid_Adapter(String[] movies, int[] imgs,Context context) {
        this.movies = movies;
        this.imgs = imgs;
        this.context = context;
    }

    @Override
    public int getCount() {
        return movies.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
       layoutInflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
       if(convertView==null)
       {
           view=new View(context);
           view=layoutInflater.inflate(R.layout.single_item,null);
           ImageView imageview=(ImageView) view.findViewById(R.id.movie_img);
           TextView m_textview=(TextView) view.findViewById(R.id.tv_detail);
           imageview.setImageResource(imgs[position]);
           m_textview.setText(movies[position]);

       }
       return view;
    }
}
