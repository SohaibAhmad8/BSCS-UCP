package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class about_user extends AppCompatActivity {
    TextView name_show,password_show,phone_show,userid_show;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cities_cinemas);
        name_show=findViewById(R.id.tv_name);
        password_show=findViewById(R.id.tv_password);
        phone_show=findViewById(R.id.tv_phone);
        userid_show=findViewById(R.id.tv_username);
    }

    public void show_infow()
    {
        SharedPreferences Sharedpref=getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        if(Sharedpref.contains("First Name"))
        {
            String n=Sharedpref.getString("First Name","Fname not found");
            name_show.setText(n);
        }
        if(Sharedpref.contains("User Id"))
        {
            String id=Sharedpref.getString("User Id","User ID Not Found");
            userid_show.setText(id);
        }
        if(Sharedpref.contains("Password"))
        {
            String p=Sharedpref.getString("Password","Password Not Found");
            password_show.setText(p);
        }


    }
}
